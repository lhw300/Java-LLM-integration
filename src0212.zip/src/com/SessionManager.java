package com;


import java.util.HashMap;
import java.util.Map;

public class SessionManager {

    private final Map<String, ChatSession> sessions = new HashMap<>();
    private final String defaultSystemMessage;

    public SessionManager(String defaultSystemMessage) {
        this.defaultSystemMessage = defaultSystemMessage;
    }

    // ��ȡ�򴴽�һ���ͻ��Ự
    public ChatSession getSession(String clientId) {
        return sessions.computeIfAbsent(clientId,
                id -> new ChatSession(defaultSystemMessage));
    }

    // ��ѡ������һ���ͻ��Ự
    public void removeSession(String clientId) {
        sessions.remove(clientId);
    }
}
